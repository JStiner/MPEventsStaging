# MP Community Events

Static site for Mt. Pulaski community event pages and calendar views.

## Current Branch Structure

This version organizes event data by folder under `data/` so each event can evolve independently.

## Data Layout

- `data/covh/` → Christmas on Vinegar Hill
- `data/2ndfriday/` → 2nd Fridays
- `data/fallfest/` → Fall Fest
- `data/community-events/` → Community events
- `data/high-school-events/` → High school events
- `data/town-services/` → Town services

## COVH Notes

Christmas on Vinegar Hill is split into separate files for:

- event metadata
- locations
- schedule
- vendors
- map metadata
- flyer content

Downloadable pamphlet and vendor-reference links were removed in favor of structured data rendered in the UI.

## Running Locally

Use a local web server or GitHub Pages. Loading files directly from a ZIP or local filesystem may block fetch requests in the browser.
