# CSS

Styles for the site live here.

- `styles.css` contains the shared layout, cards, tabs, map, calendar, and flyer styling.
- Keep event-specific styling minimal and prefer shared utility patterns so pages stay consistent.
