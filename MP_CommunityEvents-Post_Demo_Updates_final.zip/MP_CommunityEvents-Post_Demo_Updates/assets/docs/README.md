# Documents

Place optional source documents here only when the public site needs them.

Current COVH pamphlet and vendor-reference downloads were intentionally removed from the UI in favor of structured JSON data.
