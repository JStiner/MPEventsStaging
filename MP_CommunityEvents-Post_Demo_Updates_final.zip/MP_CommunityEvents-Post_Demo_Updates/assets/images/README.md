# Images

Store shared static images here.

Use this folder for public-facing graphics, logos, map images, or event artwork that should be bundled with the site.
