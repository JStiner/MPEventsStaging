# JavaScript

- `home.js` powers the homepage calendar and event summary cards.
- `app.js` powers individual event detail pages, tabs, map pins, modal details, vendor cards, and flyer rendering.

Both scripts support event data loaded from `data/<event>/event.json`.
