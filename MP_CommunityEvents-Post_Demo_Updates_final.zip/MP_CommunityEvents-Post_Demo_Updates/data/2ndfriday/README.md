# 2nd Fridays

This folder contains the structured data for 2nd Fridays.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
