# Data

Each event has its own folder.

## Standard Pattern

- `event.json` → primary event metadata
- optional supporting files such as:
  - `locations.json`
  - `schedule.json`
  - `vendors.json`
  - `map.json`
  - `flyer.json`

Folder names can use short internal codes like `covh`, but public UI text should use full event names.
