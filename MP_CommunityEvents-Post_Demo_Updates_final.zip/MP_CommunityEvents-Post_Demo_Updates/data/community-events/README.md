# Community Events

This folder contains the structured data for Community Events.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
