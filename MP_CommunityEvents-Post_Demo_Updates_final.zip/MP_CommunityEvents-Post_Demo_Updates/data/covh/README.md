# Christmas on Vinegar Hill

This folder contains the structured data for Christmas on Vinegar Hill.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
This event is intentionally split into multiple JSON files so the flyer, location list, schedule, vendors, and map-related metadata can be maintained independently.
