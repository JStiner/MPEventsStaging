# Fall Fest

This folder contains the structured data for Fall Fest.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
