# High School Events

This folder contains the structured data for High School Events.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
