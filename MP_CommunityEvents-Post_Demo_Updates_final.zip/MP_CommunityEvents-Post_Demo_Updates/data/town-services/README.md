# Town Services

This folder contains the structured data for Town Services.

- `event.json` is the entry point used by the site.
- Supporting JSON files should stay focused on one concern per file.
